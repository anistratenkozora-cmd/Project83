#include <iostream>
#include <cstring>
#include <windows.h>

using namespace std;

//                                      САМОСТІЙНА РОБОТА: "ТАБІР ГЕРОЇВ"

//  Сюжет: ти - керівник табору героїв. До табору приходять нові герої, яких потрібно записати, підвищувати їм рівень, видавати зброю,
//  лікувати чи наносити їм шкоду в боях, і, на жаль, іноді герой гине в бою і його потрібно прибрати зі списку. Наприкінці - визначити
//  найсильнішого героя табору і загальну "силу" всього табору.

//  Структури нижче ВЖЕ ГОТОВІ - не потрібно їх змінювати, лише використовувати. Зверни увагу: Character - це ВКЛАДЕНА структура
//  (містить Stats і Item як поля), а PartyList - це масив структур Character (кожен герой табору).

struct Stats
{
    int strength;       // сила
    int agility;        // спритність
    int intelligence;   // інтелект
};

struct Item
{
    char name[50];      // назва зброї
    int power;          // сила зброї
};

struct Character
{
    char name[100];     // ім'я героя
    char classType[50]; // клас героя ("Воїн", "Маг", "Лучник" тощо)
    int level;          // рівень героя
    int hp;             // здоров'я
    Stats stats;        // вкладена структура - характеристики
    Item weapon;        // вкладена структура - поточна зброя
};

// Обгортка: динамічний масив героїв табору + його поточний розмір РАЗОМ
struct PartyList
{
    Character* heroes = nullptr;     // покажчик на динамічний масив героїв
    int size = 0;                    // скільки героїв реально зараз у таборі
};

void recruitHero(PartyList& party, Character newHero) {
    Character* newHeroes = new Character[party.size + 1];
    for (int i = 0;i < party.size;i++) {
        newHeroes[i] = party.heroes[i];
    }
    newHeroes[party.size] = newHero;
    delete[]party.heroes;
    party.heroes = newHeroes;
    party.size = party.size + 1;
}
int findHeroIndex(const PartyList& party, const char* searchName) {
    for (int i = 0;i < party.size;i++) {
        if (strcmp(party.heroes[i].name, searchName) == 0) {
            return i;
       }
       
        }
    
        return -1;

    }
Character getHeroByName(const PartyList& party, const char* searchName) {
    int index = findHeroIndex(party, searchName);
    if (index != -1) {
        return party.heroes[index];
    }
    else if (index == -1) {
        Character emptyHero;

            emptyHero.level = -1;
        return emptyHero;
    }

}
void printParty(const PartyList& party) {
    for (int i = 0;i < party.size;i++) {
            cout << party.heroes[i].name<<endl;
        cout << party.heroes[i].classType << endl;
        cout << party.heroes[i].level << endl;
        cout << party.heroes[i].hp << endl;

        cout << party.heroes[i].stats.strength << endl;
        cout << party.heroes[i].stats.agility << endl;
        cout << party.heroes[i].stats.intelligence << endl;

        cout << party.heroes[i].weapon.name << endl;

    }
}
bool levelUp(PartyList& party, const char* searchName) {


    int index = findHeroIndex(party, searchName);
    if (index != -1) {
        party.heroes[index].level += 1;
        party.heroes[index].hp += 10;
        return true;
    }
    return false;
}
bool equipWeapon(PartyList& party, const char* searchName, Item newweapon) {
    int index = findHeroIndex(party, searchName);
    if (index != -1) {
        party.heroes[index].weapon = newweapon;

        return true;
    }
    return false;
    }
bool damageHero(PartyList& party, const char* searchName, int amount) {
    int index = findHeroIndex(party, searchName);
    if (index != -1) {
        party.heroes[index].hp -= amount;
        
        if (party.heroes[index].hp < 0) {
            party.heroes[index].hp = 0;
        }
        return true;
    }
    return false;
}
bool healHero(PartyList& party, const char* searchName, int amount) {
    int index = findHeroIndex(party, searchName);
    if (index != -1) {
        party.heroes[index].hp += amount;
        if (party.heroes[index].hp >= 100) {
            party.heroes[index].hp = 100;
        }
        return true;
    }
    return false;
}



















//  ================== ЕТАП 1: CREATE + READ ==================

//  Завдання 1.1. Напишіть функцію
//      void recruitHero(PartyList& party, Character newHero);
//  яка додає нового героя В КІНЕЦЬ динамічного масиву героїв - за принципом:
//  -   виділити новий масив на +1,
//  -   скопіювати старі записи,
//  -   додати новий,
//  -   звільнити старий масив.

//  Завдання 1.2. Напишіть функцію
//      int findHeroIndex(const PartyList& party, const char* searchName);
//  -   яка повертає ІНДЕКС героя за іменем,
//  -   або -1, якщо такого героя в таборі немає.
//  -   Порівнюйте імена через strcmp.

//  Завдання 1.3. Напишіть функцію
//      Character getHeroByName(const PartyList& party, const char* searchName);
//  -   яка повертає КОПІЮ героя за іменем (скористайтесь findHeroIndex).
//  -   Якщо героя не знайдено - поверніть "порожнього" героя з level = -1.

//  Завдання 1.4. Напишіть функцію
//      void printParty(const PartyList& party);
//  -   яка виводить УСІХ героїв табору: ім'я, клас, рівень, hp,
//  -   ЗВЕРНІТЬ УВАГУ - потрібно вивести і вкладені поля: силу/спритність/інтелект (stats) і назву поточної зброї (weapon.name).


//  ================== ЕТАП 2: UPDATE ==================

//  Завдання 2.1. Напишіть функцію
//      bool levelUp(PartyList& party, const char* searchName);
//  -   яка знаходить героя за іменем
//  -   збільшує level на 1, а hp - на 10.
//  -   Повертає false, якщо героя не знайдено.

//  Завдання 2.2. Напишіть функцію
//      bool equipWeapon(PartyList& party, const char* searchName, Item newWeapon);
//  -   яка змінює ПОЛЕ weapon (вкладену структуру) героя на нову зброю (заміняє І назву, І power).
//  -   Повертає false, якщо героя не знайдено.

//  Завдання 2.3. Напишіть функцію
//      bool damageHero(PartyList& party, const char* searchName, int amount);
//  -   яка зменшує hp героя на amount.
//  -   ВАЖЛИВО: hp не повинно ставати меншим за 0 (якщо amount більший за поточне hp - встановіть hp = 0).

//  Завдання 2.4. Напишіть функцію
//      bool healHero(PartyList& party, const char* searchName, int amount);
//  -   яка збільшує hp героя на amount, але hp НЕ повинно перевищувати 100 (якщо після лікування вийшло би більше 100 - встановіть hp = 100).


//  ================== ЕТАП 3: DELETE + аналітика ==================

//  Завдання 3.1. Напишіть функцію
//      bool dismissHero(PartyList& party, const char* searchName);
//  яка видаляє героя з табору за іменем за принципом:
//  -   виділити новий масив на -1,
//  -   скопіювати всіх, окрім видаленого, звільнити старий масив.
//  -   Не забудьте про особливий випадок, коли герой останній у таборі!

//  Завдання 3.2. Напишіть функцію
//      int totalPartyPower(const PartyList& party);
//  -   яка обчислює ЗАГАЛЬНУ силу всього табору - суму по всіх героях виразу (level * 10 + weapon.power) для кожного героя.

//  Завдання 3.3. Напишіть функцію
//      int findStrongestHeroIndex(const PartyList& party);
//  -   яка повертає ІНДЕКС героя з найбільшим значенням (stats.strength + stats.agility + stats.intelligence).
//  -   Якщо табір порожній - поверніть -1.

//  Завдання 3.4. Напишіть функцію
//      void sortByLevelDescending(PartyList& party);
//  -   яка сортує масив героїв за СПАДАННЯМ рівня (level), методом бульбашки


//  ================== ПЕРЕВІРКА: демонстрація в main() ==================
//  Заповніть main() власним сюжетом, використовуючи ВСІ написані функції. Орієнтовний сценарій (можете придумати свій):
//
//  1. Наберіть до табору 3-4 героїв (recruitHero) з різними класами, рівнями, характеристиками і початковою зброєю.
//  2. Виведіть табір (printParty).
//  3. Прочитайте одного героя за іменем (getHeroByName), виведіть інформацію про нього окремо.
//  4. Підвищіть рівень одному з героїв (levelUp).
//  5. Видайте новому герою кращу зброю (equipWeapon).
//  6. Влаштуйте "бій" - один герой отримує шкоду (damageHero), потім лікується (healHero).
//  7. Обчисліть і виведіть загальну силу табору (totalPartyPower).
//  8. Знайдіть і виведіть найсильнішого героя (findStrongestHeroIndex).
//  9. Один герой "гине в бою" - видаліть його з табору (dismissHero).
//  10. Виведіть табір ще раз, щоб побачити результат усіх дій.
//  11. Не забудьте звільнити пам'ять (delete[] party.heroes) наприкінці!

int main()
{
    SetConsoleCP(65001);
    SetConsoleOutputCP(65001);

    PartyList party;

    // ЗАПОВНІТЬ ТУТ СЮЖЕТ ГРИ, ВИКОРИСТОВУЮЧИ ВСІ ФУНКЦІЇ, ЯКІ ВИ НАПИСАЛИ

    return 0;
}